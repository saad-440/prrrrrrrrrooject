﻿namespace final_calculator_project
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges33 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges34 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges35 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges36 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges37 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges38 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges39 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges40 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges41 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges42 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges43 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges44 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges45 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            dataGridView1 = new DataGridView();
            guna2Button18 = new Guna.UI2.WinForms.Guna2Button();
            guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            panel1 = new Panel();
            txtresult = new TextBox();
            textBox2 = new TextBox();
            label2 = new Label();
            label1 = new Label();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button19 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button20 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button17 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button13 = new Guna.UI2.WinForms.Guna2Button();
            Button3 = new Guna.UI2.WinForms.Guna2Button();
            Button2 = new Guna.UI2.WinForms.Guna2Button();
            Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button9 = new Guna.UI2.WinForms.Guna2Button();
            Button6 = new Guna.UI2.WinForms.Guna2Button();
            Button5 = new Guna.UI2.WinForms.Guna2Button();
            Button4 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            Button9 = new Guna.UI2.WinForms.Guna2Button();
            Button8 = new Guna.UI2.WinForms.Guna2Button();
            Button7 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            BtC = new Guna.UI2.WinForms.Guna2Button();
            BtCE = new Guna.UI2.WinForms.Guna2Button();
            guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            textBox3 = new TextBox();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(32, 32, 32);
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.GridColor = Color.FromArgb(32, 32, 32);
            dataGridView1.Location = new Point(106, 92);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(240, 177);
            dataGridView1.TabIndex = 24;
            // 
            // guna2Button18
            // 
            guna2Button18.BackColor = Color.FromArgb(32, 32, 32);
            guna2Button18.BorderRadius = 10;
            guna2Button18.Cursor = Cursors.Hand;
            guna2Button18.CustomizableEdges = customizableEdges1;
            guna2Button18.DisabledState.BorderColor = Color.DarkGray;
            guna2Button18.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button18.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button18.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button18.FillColor = Color.FromArgb(78, 78, 78);
            guna2Button18.Font = new Font("Microsoft JhengHei", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button18.ForeColor = Color.White;
            guna2Button18.Location = new Point(51, 361);
            guna2Button18.Name = "guna2Button18";
            guna2Button18.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2Button18.Size = new Size(254, 29);
            guna2Button18.TabIndex = 26;
            guna2Button18.Text = "SHOW";
            guna2Button18.Click += guna2Button18_Click;
            // 
            // guna2CircleButton1
            // 
            guna2CircleButton1.Cursor = Cursors.Hand;
            guna2CircleButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton1.FillColor = Color.FromArgb(32, 32, 32);
            guna2CircleButton1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2CircleButton1.ForeColor = Color.White;
            guna2CircleButton1.Image = Properties.Resources.icons8_go_back_50;
            guna2CircleButton1.ImageSize = new Size(30, 30);
            guna2CircleButton1.Location = new Point(17, 10);
            guna2CircleButton1.Name = "guna2CircleButton1";
            guna2CircleButton1.ShadowDecoration.CustomizableEdges = customizableEdges3;
            guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton1.Size = new Size(30, 30);
            guna2CircleButton1.TabIndex = 27;
            guna2CircleButton1.Click += guna2CircleButton1_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(txtresult);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(guna2Button1);
            panel1.Controls.Add(guna2Button19);
            panel1.Controls.Add(guna2Button20);
            panel1.Controls.Add(guna2Button17);
            panel1.Controls.Add(guna2Button13);
            panel1.Controls.Add(Button3);
            panel1.Controls.Add(Button2);
            panel1.Controls.Add(Button1);
            panel1.Controls.Add(guna2Button9);
            panel1.Controls.Add(Button6);
            panel1.Controls.Add(Button5);
            panel1.Controls.Add(Button4);
            panel1.Controls.Add(guna2Button8);
            panel1.Controls.Add(Button9);
            panel1.Controls.Add(Button8);
            panel1.Controls.Add(Button7);
            panel1.Controls.Add(guna2Button4);
            panel1.Controls.Add(BtC);
            panel1.Controls.Add(BtCE);
            panel1.Controls.Add(guna2Button2);
            panel1.Controls.Add(TextBox1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(358, 461);
            panel1.TabIndex = 28;
            panel1.Paint += panel1_Paint;
            // 
            // txtresult
            // 
            txtresult.BackColor = Color.FromArgb(32, 32, 32);
            txtresult.BorderStyle = BorderStyle.None;
            txtresult.ForeColor = Color.FromArgb(32, 32, 32);
            txtresult.Location = new Point(142, 6);
            txtresult.Name = "txtresult";
            txtresult.Size = new Size(100, 16);
            txtresult.TabIndex = 51;
            txtresult.Visible = false;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(32, 32, 32);
            textBox2.BorderStyle = BorderStyle.None;
            textBox2.Font = new Font("Unispace", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            textBox2.ForeColor = Color.Teal;
            textBox2.Location = new Point(19, 5);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 20);
            textBox2.TabIndex = 50;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Unispace", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(32, 32, 32);
            label2.Location = new Point(323, 6);
            label2.Name = "label2";
            label2.Size = new Size(0, 19);
            label2.TabIndex = 49;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Unispace", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(32, 32, 32);
            label1.Location = new Point(296, 6);
            label1.Name = "label1";
            label1.Size = new Size(0, 19);
            label1.TabIndex = 48;
            // 
            // guna2Button1
            // 
            guna2Button1.BackColor = Color.FromArgb(32, 32, 32);
            guna2Button1.BorderRadius = 10;
            guna2Button1.CustomizableEdges = customizableEdges4;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.FillColor = Color.FromArgb(78, 78, 78);
            guna2Button1.Font = new Font("Microsoft JhengHei", 24F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Location = new Point(180, 400);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges5;
            guna2Button1.Size = new Size(83, 56);
            guna2Button1.TabIndex = 47;
            guna2Button1.Text = "↻";
            guna2Button1.Click += guna2Button1_Click;
            // 
            // guna2Button19
            // 
            guna2Button19.BackColor = Color.FromArgb(32, 32, 32);
            guna2Button19.BorderRadius = 10;
            guna2Button19.CustomizableEdges = customizableEdges6;
            guna2Button19.DisabledState.BorderColor = Color.DarkGray;
            guna2Button19.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button19.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button19.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button19.FillColor = Color.FromArgb(78, 78, 78);
            guna2Button19.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button19.ForeColor = Color.White;
            guna2Button19.Location = new Point(95, 400);
            guna2Button19.Name = "guna2Button19";
            guna2Button19.ShadowDecoration.CustomizableEdges = customizableEdges7;
            guna2Button19.Size = new Size(83, 56);
            guna2Button19.TabIndex = 46;
            guna2Button19.Text = "0";
            guna2Button19.Click += guna2Button19_Click;
            // 
            // guna2Button20
            // 
            guna2Button20.BackColor = Color.FromArgb(32, 32, 32);
            guna2Button20.BorderRadius = 10;
            guna2Button20.CustomizableEdges = customizableEdges8;
            guna2Button20.DisabledState.BorderColor = Color.DarkGray;
            guna2Button20.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button20.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button20.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button20.FillColor = Color.FromArgb(78, 78, 78);
            guna2Button20.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button20.ForeColor = Color.White;
            guna2Button20.Location = new Point(10, 400);
            guna2Button20.Name = "guna2Button20";
            guna2Button20.ShadowDecoration.CustomizableEdges = customizableEdges9;
            guna2Button20.Size = new Size(83, 56);
            guna2Button20.TabIndex = 45;
            guna2Button20.Text = "-";
            guna2Button20.Click += guna2Button20_Click;
            // 
            // guna2Button17
            // 
            guna2Button17.BackColor = Color.FromArgb(32, 32, 32);
            guna2Button17.BorderRadius = 10;
            guna2Button17.CustomizableEdges = customizableEdges10;
            guna2Button17.DisabledState.BorderColor = Color.DarkGray;
            guna2Button17.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button17.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button17.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button17.FillColor = Color.FromArgb(59, 59, 59);
            guna2Button17.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button17.ForeColor = Color.White;
            guna2Button17.Location = new Point(265, 152);
            guna2Button17.Name = "guna2Button17";
            guna2Button17.ShadowDecoration.CustomizableEdges = customizableEdges11;
            guna2Button17.Size = new Size(83, 56);
            guna2Button17.TabIndex = 44;
            guna2Button17.Text = "÷";
            guna2Button17.Click += guna2Button17_Click;
            // 
            // guna2Button13
            // 
            guna2Button13.BackColor = Color.FromArgb(32, 32, 32);
            guna2Button13.BorderRadius = 10;
            guna2Button13.CustomizableEdges = customizableEdges12;
            guna2Button13.DisabledState.BorderColor = Color.DarkGray;
            guna2Button13.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button13.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button13.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button13.FillColor = Color.FromArgb(59, 59, 59);
            guna2Button13.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button13.ForeColor = Color.White;
            guna2Button13.Location = new Point(265, 338);
            guna2Button13.Name = "guna2Button13";
            guna2Button13.ShadowDecoration.CustomizableEdges = customizableEdges13;
            guna2Button13.Size = new Size(83, 56);
            guna2Button13.TabIndex = 43;
            guna2Button13.Text = "+";
            guna2Button13.Click += guna2Button13_Click;
            // 
            // Button3
            // 
            Button3.BackColor = Color.FromArgb(32, 32, 32);
            Button3.BorderRadius = 10;
            Button3.CustomizableEdges = customizableEdges14;
            Button3.DisabledState.BorderColor = Color.DarkGray;
            Button3.DisabledState.CustomBorderColor = Color.DarkGray;
            Button3.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            Button3.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            Button3.FillColor = Color.FromArgb(78, 78, 78);
            Button3.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            Button3.ForeColor = Color.White;
            Button3.Location = new Point(180, 338);
            Button3.Name = "Button3";
            Button3.ShadowDecoration.CustomizableEdges = customizableEdges15;
            Button3.Size = new Size(83, 56);
            Button3.TabIndex = 42;
            Button3.Text = "3";
            Button3.Click += Button3_Click;
            // 
            // Button2
            // 
            Button2.BackColor = Color.FromArgb(32, 32, 32);
            Button2.BorderRadius = 10;
            Button2.CustomizableEdges = customizableEdges16;
            Button2.DisabledState.BorderColor = Color.DarkGray;
            Button2.DisabledState.CustomBorderColor = Color.DarkGray;
            Button2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            Button2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            Button2.FillColor = Color.FromArgb(78, 78, 78);
            Button2.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            Button2.ForeColor = Color.White;
            Button2.Location = new Point(95, 338);
            Button2.Name = "Button2";
            Button2.ShadowDecoration.CustomizableEdges = customizableEdges17;
            Button2.Size = new Size(83, 56);
            Button2.TabIndex = 41;
            Button2.Text = "2";
            Button2.Click += Button2_Click;
            // 
            // Button1
            // 
            Button1.BackColor = Color.FromArgb(32, 32, 32);
            Button1.BorderRadius = 10;
            Button1.CustomizableEdges = customizableEdges18;
            Button1.DisabledState.BorderColor = Color.DarkGray;
            Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            Button1.FillColor = Color.FromArgb(78, 78, 78);
            Button1.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            Button1.ForeColor = Color.White;
            Button1.Location = new Point(10, 338);
            Button1.Name = "Button1";
            Button1.ShadowDecoration.CustomizableEdges = customizableEdges19;
            Button1.Size = new Size(83, 56);
            Button1.TabIndex = 40;
            Button1.Text = "1";
            Button1.Click += Button1_Click;
            // 
            // guna2Button9
            // 
            guna2Button9.BackColor = Color.FromArgb(32, 32, 32);
            guna2Button9.BorderRadius = 10;
            guna2Button9.CustomizableEdges = customizableEdges20;
            guna2Button9.DisabledState.BorderColor = Color.DarkGray;
            guna2Button9.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button9.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button9.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button9.FillColor = Color.FromArgb(59, 59, 59);
            guna2Button9.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button9.ForeColor = Color.White;
            guna2Button9.Location = new Point(265, 276);
            guna2Button9.Name = "guna2Button9";
            guna2Button9.ShadowDecoration.CustomizableEdges = customizableEdges21;
            guna2Button9.Size = new Size(83, 56);
            guna2Button9.TabIndex = 39;
            guna2Button9.Text = "–";
            guna2Button9.Click += guna2Button9_Click;
            // 
            // Button6
            // 
            Button6.BackColor = Color.FromArgb(32, 32, 32);
            Button6.BorderRadius = 10;
            Button6.CustomizableEdges = customizableEdges22;
            Button6.DisabledState.BorderColor = Color.DarkGray;
            Button6.DisabledState.CustomBorderColor = Color.DarkGray;
            Button6.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            Button6.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            Button6.FillColor = Color.FromArgb(78, 78, 78);
            Button6.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            Button6.ForeColor = Color.White;
            Button6.Location = new Point(180, 276);
            Button6.Name = "Button6";
            Button6.ShadowDecoration.CustomizableEdges = customizableEdges23;
            Button6.Size = new Size(83, 56);
            Button6.TabIndex = 38;
            Button6.Text = "6";
            Button6.Click += Button6_Click;
            // 
            // Button5
            // 
            Button5.BackColor = Color.FromArgb(32, 32, 32);
            Button5.BorderRadius = 10;
            Button5.CustomizableEdges = customizableEdges24;
            Button5.DisabledState.BorderColor = Color.DarkGray;
            Button5.DisabledState.CustomBorderColor = Color.DarkGray;
            Button5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            Button5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            Button5.FillColor = Color.FromArgb(78, 78, 78);
            Button5.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            Button5.ForeColor = Color.White;
            Button5.Location = new Point(95, 276);
            Button5.Name = "Button5";
            Button5.ShadowDecoration.CustomizableEdges = customizableEdges25;
            Button5.Size = new Size(83, 56);
            Button5.TabIndex = 37;
            Button5.Text = "5";
            Button5.Click += Button5_Click;
            // 
            // Button4
            // 
            Button4.BackColor = Color.FromArgb(32, 32, 32);
            Button4.BorderRadius = 10;
            Button4.CustomizableEdges = customizableEdges26;
            Button4.DisabledState.BorderColor = Color.DarkGray;
            Button4.DisabledState.CustomBorderColor = Color.DarkGray;
            Button4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            Button4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            Button4.FillColor = Color.FromArgb(78, 78, 78);
            Button4.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            Button4.ForeColor = Color.White;
            Button4.Location = new Point(10, 276);
            Button4.Name = "Button4";
            Button4.ShadowDecoration.CustomizableEdges = customizableEdges27;
            Button4.Size = new Size(83, 56);
            Button4.TabIndex = 36;
            Button4.Text = "4";
            Button4.Click += Button4_Click;
            // 
            // guna2Button8
            // 
            guna2Button8.BackColor = Color.FromArgb(32, 32, 32);
            guna2Button8.BorderRadius = 10;
            guna2Button8.CustomizableEdges = customizableEdges28;
            guna2Button8.DisabledState.BorderColor = Color.DarkGray;
            guna2Button8.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button8.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button8.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button8.FillColor = Color.FromArgb(59, 59, 59);
            guna2Button8.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button8.ForeColor = Color.White;
            guna2Button8.Location = new Point(265, 214);
            guna2Button8.Name = "guna2Button8";
            guna2Button8.ShadowDecoration.CustomizableEdges = customizableEdges29;
            guna2Button8.Size = new Size(83, 56);
            guna2Button8.TabIndex = 35;
            guna2Button8.Text = "×";
            guna2Button8.Click += guna2Button8_Click;
            // 
            // Button9
            // 
            Button9.BackColor = Color.FromArgb(32, 32, 32);
            Button9.BorderRadius = 10;
            Button9.CustomizableEdges = customizableEdges30;
            Button9.DisabledState.BorderColor = Color.DarkGray;
            Button9.DisabledState.CustomBorderColor = Color.DarkGray;
            Button9.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            Button9.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            Button9.FillColor = Color.FromArgb(78, 78, 78);
            Button9.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            Button9.ForeColor = Color.White;
            Button9.Location = new Point(180, 214);
            Button9.Name = "Button9";
            Button9.ShadowDecoration.CustomizableEdges = customizableEdges31;
            Button9.Size = new Size(83, 56);
            Button9.TabIndex = 34;
            Button9.Text = "9";
            Button9.Click += Button9_Click;
            // 
            // Button8
            // 
            Button8.BackColor = Color.FromArgb(32, 32, 32);
            Button8.BorderRadius = 10;
            Button8.CustomizableEdges = customizableEdges32;
            Button8.DisabledState.BorderColor = Color.DarkGray;
            Button8.DisabledState.CustomBorderColor = Color.DarkGray;
            Button8.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            Button8.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            Button8.FillColor = Color.FromArgb(78, 78, 78);
            Button8.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            Button8.ForeColor = Color.White;
            Button8.Location = new Point(95, 214);
            Button8.Name = "Button8";
            Button8.ShadowDecoration.CustomizableEdges = customizableEdges33;
            Button8.Size = new Size(83, 56);
            Button8.TabIndex = 33;
            Button8.Text = "8";
            Button8.Click += Button8_Click;
            // 
            // Button7
            // 
            Button7.BackColor = Color.FromArgb(32, 32, 32);
            Button7.BorderRadius = 10;
            Button7.CustomizableEdges = customizableEdges34;
            Button7.DisabledState.BorderColor = Color.DarkGray;
            Button7.DisabledState.CustomBorderColor = Color.DarkGray;
            Button7.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            Button7.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            Button7.FillColor = Color.FromArgb(78, 78, 78);
            Button7.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            Button7.ForeColor = Color.White;
            Button7.Location = new Point(10, 214);
            Button7.Name = "Button7";
            Button7.ShadowDecoration.CustomizableEdges = customizableEdges35;
            Button7.Size = new Size(83, 56);
            Button7.TabIndex = 32;
            Button7.Text = "7";
            Button7.Click += Button7_Click;
            // 
            // guna2Button4
            // 
            guna2Button4.BackColor = Color.FromArgb(32, 32, 32);
            guna2Button4.BorderRadius = 10;
            guna2Button4.CustomizableEdges = customizableEdges36;
            guna2Button4.DisabledState.BorderColor = Color.DarkGray;
            guna2Button4.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button4.FillColor = Color.FromArgb(10, 221, 116);
            guna2Button4.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button4.ForeColor = Color.White;
            guna2Button4.Location = new Point(265, 400);
            guna2Button4.Name = "guna2Button4";
            guna2Button4.ShadowDecoration.CustomizableEdges = customizableEdges37;
            guna2Button4.Size = new Size(83, 56);
            guna2Button4.TabIndex = 31;
            guna2Button4.Text = "=";
            guna2Button4.Click += guna2Button4_Click;
            // 
            // BtC
            // 
            BtC.BackColor = Color.FromArgb(32, 32, 32);
            BtC.BorderRadius = 10;
            BtC.CustomizableEdges = customizableEdges38;
            BtC.DisabledState.BorderColor = Color.DarkGray;
            BtC.DisabledState.CustomBorderColor = Color.DarkGray;
            BtC.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            BtC.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            BtC.FillColor = Color.FromArgb(59, 59, 59);
            BtC.Font = new Font("Microsoft JhengHei", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            BtC.ForeColor = Color.White;
            BtC.Location = new Point(180, 152);
            BtC.Name = "BtC";
            BtC.ShadowDecoration.CustomizableEdges = customizableEdges39;
            BtC.Size = new Size(83, 56);
            BtC.TabIndex = 30;
            BtC.Text = "C";
            BtC.Click += BtC_Click;
            // 
            // BtCE
            // 
            BtCE.BackColor = Color.FromArgb(32, 32, 32);
            BtCE.BorderRadius = 10;
            BtCE.CustomizableEdges = customizableEdges40;
            BtCE.DisabledState.BorderColor = Color.DarkGray;
            BtCE.DisabledState.CustomBorderColor = Color.DarkGray;
            BtCE.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            BtCE.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            BtCE.FillColor = Color.FromArgb(59, 59, 59);
            BtCE.Font = new Font("Microsoft JhengHei", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            BtCE.ForeColor = Color.White;
            BtCE.Location = new Point(95, 152);
            BtCE.Name = "BtCE";
            BtCE.ShadowDecoration.CustomizableEdges = customizableEdges41;
            BtCE.Size = new Size(83, 56);
            BtCE.TabIndex = 29;
            BtCE.Text = "CE";
            BtCE.Click += BtCE_Click;
            // 
            // guna2Button2
            // 
            guna2Button2.BackColor = Color.FromArgb(32, 32, 32);
            guna2Button2.BorderRadius = 10;
            guna2Button2.CustomizableEdges = customizableEdges42;
            guna2Button2.DisabledState.BorderColor = Color.DarkGray;
            guna2Button2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button2.FillColor = Color.FromArgb(59, 59, 59);
            guna2Button2.Font = new Font("Microsoft JhengHei", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button2.ForeColor = Color.White;
            guna2Button2.Location = new Point(10, 152);
            guna2Button2.Name = "guna2Button2";
            guna2Button2.ShadowDecoration.CustomizableEdges = customizableEdges43;
            guna2Button2.Size = new Size(83, 56);
            guna2Button2.TabIndex = 28;
            guna2Button2.Text = "%";
            guna2Button2.Click += guna2Button2_Click;
            // 
            // TextBox1
            // 
            TextBox1.BackColor = Color.FromArgb(32, 32, 32);
            TextBox1.BorderColor = Color.FromArgb(32, 32, 32);
            TextBox1.BorderRadius = 8;
            TextBox1.CustomizableEdges = customizableEdges44;
            TextBox1.DefaultText = "";
            TextBox1.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            TextBox1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            TextBox1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            TextBox1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            TextBox1.FillColor = Color.FromArgb(61, 61, 67);
            TextBox1.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            TextBox1.Font = new Font("Unispace", 21.75F, FontStyle.Bold, GraphicsUnit.Point);
            TextBox1.ForeColor = Color.Teal;
            TextBox1.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            TextBox1.Location = new Point(14, 27);
            TextBox1.Margin = new Padding(7);
            TextBox1.Name = "TextBox1";
            TextBox1.PasswordChar = '\0';
            TextBox1.PlaceholderForeColor = Color.MediumOrchid;
            TextBox1.PlaceholderText = "";
            TextBox1.SelectedText = "";
            TextBox1.ShadowDecoration.CustomizableEdges = customizableEdges45;
            TextBox1.Size = new Size(326, 104);
            TextBox1.TabIndex = 27;
            TextBox1.TextChanged += TextBox1_TextChanged;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(32, 32, 32);
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Font = new Font("Unispace", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            textBox3.ForeColor = Color.FromArgb(32, 32, 32);
            textBox3.Location = new Point(205, 10);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 20);
            textBox3.TabIndex = 52;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft JhengHei", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.Coral;
            label3.Location = new Point(89, 280);
            label3.Name = "label3";
            label3.Size = new Size(172, 17);
            label3.TabIndex = 53;
            label3.Text = "The Last One Is The Recent ";
            label3.Click += label3_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(32, 32, 32);
            ClientSize = new Size(358, 461);
            Controls.Add(panel1);
            Controls.Add(guna2CircleButton1);
            Controls.Add(guna2Button18);
            Controls.Add(dataGridView1);
            Controls.Add(textBox3);
            Controls.Add(label3);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView dataGridView1;
        private Guna.UI2.WinForms.Guna2Button guna2Button18;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Panel panel1;
        private TextBox txtresult;
        private TextBox textBox2;
        private Label label2;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button19;
        private Guna.UI2.WinForms.Guna2Button guna2Button20;
        private Guna.UI2.WinForms.Guna2Button guna2Button17;
        private Guna.UI2.WinForms.Guna2Button guna2Button13;
        private Guna.UI2.WinForms.Guna2Button Button3;
        private Guna.UI2.WinForms.Guna2Button Button2;
        private Guna.UI2.WinForms.Guna2Button Button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button9;
        private Guna.UI2.WinForms.Guna2Button Button6;
        private Guna.UI2.WinForms.Guna2Button Button5;
        private Guna.UI2.WinForms.Guna2Button Button4;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button Button9;
        private Guna.UI2.WinForms.Guna2Button Button8;
        private Guna.UI2.WinForms.Guna2Button Button7;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button BtC;
        private Guna.UI2.WinForms.Guna2Button BtCE;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2TextBox TextBox1;
        private TextBox textBox3;
        private Label label3;
    }
}